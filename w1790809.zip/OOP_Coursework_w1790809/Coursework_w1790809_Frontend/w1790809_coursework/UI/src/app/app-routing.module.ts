import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {PointTableComponent} from './point-table/point-table.component';
import {MatchGeneratorComponent } from'./match-generator/match-generator.component';

import { HttpClientModule } from '@angular/common/http';

const routes: Routes = [{path : '', component: HomeComponent}, {path : 'pointTable', component: PointTableComponent} , {path : 'matchgen', component:MatchGeneratorComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes),HttpClientModule],
  exports: [RouterModule]
})

export class AppRoutingModule { }
