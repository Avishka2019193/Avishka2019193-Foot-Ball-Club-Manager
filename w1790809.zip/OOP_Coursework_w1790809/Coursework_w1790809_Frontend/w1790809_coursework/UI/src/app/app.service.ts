import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


/**
 * Class representing application service.
 *
 * @class AppService.
 */
@Injectable()
export class AppService {
  private clubs = '/clubs';
  private matches = '/matches';


  constructor(private http: HttpClient) {
  }


  public getClubs():any {
    return this.http.get(this.clubs);
  }

  public getMatches():any {
    return this.http.get(this.matches);
  }

}
