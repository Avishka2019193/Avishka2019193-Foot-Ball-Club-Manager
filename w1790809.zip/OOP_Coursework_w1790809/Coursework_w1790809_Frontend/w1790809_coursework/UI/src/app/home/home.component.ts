import { Component, OnInit } from '@angular/core';
// import { AppService } from '../app.service';

// export interface Match{
//   HomeTeam :String;
//   HomeTeamScore:number;
//   AwayTeam : string;
//   AwayTeamScore : number;
// }

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  // matches!:Match[];

  constructor() { }

  ngOnInit(): void {
  //   this.appService.getMatches().subscribe(
  //     (data:any) => {
  //       this.matches = data;
  //       console.log(this.matches);
  // })
  }
}


