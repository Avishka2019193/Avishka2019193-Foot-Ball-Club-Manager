import { Component, OnInit } from '@angular/core';
import { PointTableService } from '../service/point-table.service';

@Component({
  selector: 'app-match-generator',
  templateUrl: './match-generator.component.html',
  styleUrls: ['./match-generator.component.css']
})

export class MatchGeneratorComponent implements OnInit {


  goal: any[] = [];
  constructor(public pointTableService:PointTableService) {
    this.pointTableService.goalkeeper().subscribe(goalkeeperlist=>{this.goal=goalkeeperlist});
  }

   // @ts-ignore
  hometeam : string;
  // @ts-ignore
  regNumOne: number;
  // @ts-ignore
  awayteam: string;
  // @ts-ignore
  regNumTwo: number;
  // @ts-ignore
  scoreOne: number;
  // @ts-ignore
  scoreTwo: number;
    // @ts-ignore
  alert:string;

  ngOnInit(): void {
    
      }
    
  

  _autoGenerateNumber(min: number, max: number): number {
    const rand = Math.floor(Math.random() * (max - min + 1)) + min;
    return rand;
  }

  getRandomValues(): void {
   
    let clubOneIndex: number;
    let clubTwoIndex: number;
    do {
      clubOneIndex = this._autoGenerateNumber(0, (this.goal.length - 1));
      clubTwoIndex = this._autoGenerateNumber(0, (this.goal.length - 1));
    } while (clubOneIndex === clubTwoIndex);
    this.regNumOne = this.goal[clubOneIndex].registration_Number;
    this.hometeam  = this.goal[clubOneIndex].name;
    this.regNumTwo = this.goal[clubTwoIndex].registration_Number;
    this.awayteam  = this.goal[clubTwoIndex].name;
    this.scoreOne = this._autoGenerateNumber(0, 10);
    this.scoreTwo = this._autoGenerateNumber(0, 10);

    if (this.scoreOne > this.scoreTwo) {
      this.alert = 'Home Team Wins !! Congratulations!!';
    }else if (this.scoreOne === this.scoreTwo){
      this.alert = 'Match is Draw !!';
    }else {
      this.alert= ' Away Team Win !! Congratulations!!';
    }

  }}
    
