import { Component, OnInit } from '@angular/core';
import { PointTableService } from '../service/point-table.service';


@Component({
  selector: 'app-point-table',
  templateUrl: './point-table.component.html',
  styleUrls: ['./point-table.component.css']
 
})


export class PointTableComponent implements OnInit {
  title = 'custom-search-filter-example';
  searchedKeyword!: string;
    goal: any[] = [];
  

   constructor(public pointTableService:PointTableService) { 
    this.pointTableService.goalkeeper().subscribe(goalkeeperlist=>{this.goal=goalkeeperlist});
    
   }

  ngOnInit(): void {
    

}}


