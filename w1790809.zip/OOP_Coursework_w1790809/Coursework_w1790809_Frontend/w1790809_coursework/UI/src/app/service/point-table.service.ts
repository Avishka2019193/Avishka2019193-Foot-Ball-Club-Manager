import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PointTableService {

  constructor(private http:HttpClient) { }

  goalkeeper(){
    return this.http.get<any[]>('http://localhost:4200/clubs');
  
  }
}
