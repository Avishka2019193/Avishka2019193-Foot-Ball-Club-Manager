package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import models.Match;
import models.FootBallClub;
import play.mvc.Controller;
import play.mvc.Result;
import services.PremierLeagueManager;

import java.util.ArrayList;

public class LeagueController extends Controller {
    private PremierLeagueManager premierLeagueManager = new PremierLeagueManager();

    public Result getClubs(){
        ArrayList<FootBallClub> sportsClubs = premierLeagueManager.getClubs();

        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonData = mapper.convertValue(sportsClubs, JsonNode.class);
        return ok(jsonData);
    }

    public Result getMatches(){
        ArrayList<Match> matches = premierLeagueManager.getMatches();

        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonData = mapper.convertValue(matches, JsonNode.class);
        return ok(jsonData);
    }
}