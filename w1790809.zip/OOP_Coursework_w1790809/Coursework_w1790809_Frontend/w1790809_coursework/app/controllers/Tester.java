package controllers;

import services.MainCli;
public class Tester {
    public static void main(String[] args)  {
        MainCli obj = new MainCli();
        obj.displayMenu();
    }
}
