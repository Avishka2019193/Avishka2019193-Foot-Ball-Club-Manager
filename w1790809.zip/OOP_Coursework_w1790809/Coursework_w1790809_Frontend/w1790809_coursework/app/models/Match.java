package models;

import java.io.Serializable;
import java.util.Date;

public class Match implements Serializable {
        private FootBallClub HomeTeam;
        private FootBallClub AwayTeam;
        private int HomeTeamScore;
        private int AwayTeamScore;
        private Date Date;



        public FootBallClub getHomeTeam() {
            return HomeTeam;
        }

        public void setHomeTeam(FootBallClub homeTeam) {
            this.HomeTeam = homeTeam;
        }

        public FootBallClub getAwayTeam() {
            return AwayTeam;
        }

        public void setAwayTeam(FootBallClub awayTeam) {
            this.AwayTeam = awayTeam;
        }

        public int getHomeTeamScore() {
            return HomeTeamScore;
        }

        public void setHomeTeamScore(int homeTeamScore) {
            this.HomeTeamScore = homeTeamScore;
        }

        public int getAwayTeamScore() {
            return AwayTeamScore;
        }

        public void setAwayTeamScore(int awayTeamScore) {
            this.AwayTeamScore = awayTeamScore;
        }

        public Date getDate() {
            return Date;
        }

        public void setDate(Date date) {
            Date = date;
        }
    }


