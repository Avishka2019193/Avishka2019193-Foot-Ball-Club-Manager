package models;

public class SclFootBallClub extends FootBallClub {
    //Initialize variables
    private String Scl_Name;
//Creating Default Constructor
    public SclFootBallClub(){}

    //Creating  Constructor
    public SclFootBallClub(String name, String location, String name_Of_the_Manager, String registration_Number, int contact_Num, String email_of_the_Club, int num_of_Wins, int num_of_defeats, int num_of_draws, String season, int num_of_Matches, int num_of_Goals_Received, int num_of_Goals_Scored, int points, String coachName, String captain_Name, int member_Count, String scl_Name) {
        super(name, location, name_Of_the_Manager, registration_Number, contact_Num, email_of_the_Club, num_of_Wins, num_of_defeats, num_of_draws, season, num_of_Matches, num_of_Goals_Received, num_of_Goals_Scored, points, coachName, captain_Name, member_Count);
        this.Scl_Name = scl_Name;
    }
    //Getters and Setters
    public String getScl_Name() {
        return Scl_Name;
    }

    public void setScl_Name(String scl_Name) {
        this.Scl_Name = scl_Name;
    }

    @Override
    public String toString() {
        return "SclFootBallClub{" + super.toString()+
                "Scl_Name='" + Scl_Name + '\'' +
                '}';
    }
}


