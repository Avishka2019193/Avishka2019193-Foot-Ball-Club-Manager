package models;

import java.io.Serializable;
import java.util.Objects;

public abstract class  SportsClub implements Serializable {

    //Initialize variables
    private String Name;
    private String Location;
    private String Name_Of_the_Manager;
    private String Registration_Number;
    private int Contact_Num;
    private String Email_of_the_Club;

    //Creating Default Constructor
    public SportsClub() {

    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SportsClub)) return false;
        SportsClub that = (SportsClub) o;
        return getContact_Num() == that.getContact_Num() &&
                getEmail_of_the_Club() == that.getEmail_of_the_Club() &&
                getName().equals(that.getName()) &&
                getName_Of_the_Manager().equals(that.getName_Of_the_Manager()) &&
                getRegistration_Number().equals(that.getRegistration_Number());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getName_Of_the_Manager(), getRegistration_Number(), getContact_Num(), getEmail_of_the_Club());
    }
    //Creating  Constructor
    public SportsClub(String name, String location, String name_Of_the_Manager, String registration_Number, int contact_Num, String email_of_the_Club) {
        this. Name = name;
        this. Location = location;
        this.Name_Of_the_Manager = name_Of_the_Manager;
        this.Registration_Number = registration_Number;
        this. Contact_Num = contact_Num;
        this.Email_of_the_Club = email_of_the_Club;

    }

    //Getters and Setters
    public String getName() {
        return Name;
    }

    public void setName(String name) { this.Name = name;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        this.Location = location;
    }

    public String getName_Of_the_Manager() {
        return Name_Of_the_Manager;
    }

    public void setName_Of_the_Manager(String name_Of_the_Manager) {
        this.Name_Of_the_Manager = name_Of_the_Manager;
    }

    public int getContact_Num() {
        return Contact_Num;
    }

    public void setContact_Num(int contact_Num) {
        this.Contact_Num = contact_Num;
    }

    public String  getEmail_of_the_Club() {
        return Email_of_the_Club;
    }

    public String getRegistration_Number() {
        return Registration_Number;
    }

    public void setRegistration_Number(String registration_Number) {
        this.Registration_Number = registration_Number;
    }

    public void setEmail_of_the_Club(String email_of_the_Club) { this. Email_of_the_Club = email_of_the_Club; }

    @Override
    public String toString() {
        return "SportsClub{" +
                "Name='" + Name + '\'' +
                ", Location='" + Location + '\'' +
                ", Name_Of_the_Manager='" + Name_Of_the_Manager + '\'' +
                ", Registration_Number='" + Registration_Number + '\'' +
                ", Contact_Num=" + Contact_Num +
                ", Email_of_the_Club='" + Email_of_the_Club + '\'' +
                '}';
    }
}
