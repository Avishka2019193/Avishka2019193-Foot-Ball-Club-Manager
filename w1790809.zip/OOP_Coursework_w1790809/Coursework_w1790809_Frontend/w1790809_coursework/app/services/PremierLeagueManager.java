package services;


import models.FootBallClub;
import models.Match;
import models.SclFootBallClub;
import models.UniversityClub;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

public class PremierLeagueManager implements LeagueManager{
    //Creating Array Lists
    private ArrayList<FootBallClub> sportsClubsList= new ArrayList<>();
    private  ArrayList<Match>matches= new ArrayList<>();

    Validation validation = new Validation();


    //Method for saving file
    public void ReadClubMemberList() {
        FileInputStream saveMemberFileStream;
        ObjectInputStream objectInputStream = null;
        File membersFile = new File("Data.txt");
        if (membersFile.exists()) {
            try {
                saveMemberFileStream = new FileInputStream("Data.txt");
                while (saveMemberFileStream.available()>0) {
                    objectInputStream = new ObjectInputStream(saveMemberFileStream);
                    ArrayList<FootBallClub> ListSave = (ArrayList<FootBallClub>) objectInputStream.readObject();
                    sportsClubsList=ListSave;

                }
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
        }
    }
    public ArrayList<FootBallClub>getSportsClubsList(){
        ReadClubMemberList();
        Collections.sort(sportsClubsList,this::compare);
        return sportsClubsList;

    }



    public boolean CheckClub(String reg_id){
        ReadClubMemberList();
        for (FootBallClub footBallClub_RegId : sportsClubsList) {

            if (footBallClub_RegId.getRegistration_Number() .equals(reg_id)) {
                return true;
            }
        }
        return false;
    }

    //Method for adding a members to the array list
    @Override
    public void AddNewFootBallClub (FootBallClub Cmember) {

        ReadClubMemberList();

        if (Cmember instanceof FootBallClub) {
            sportsClubsList.add(Cmember);
            System.out.println();
        } else if (Cmember instanceof SclFootBallClub) {
            sportsClubsList.add(Cmember);
            System.out.println();
            System.out.println(Cmember.getName() + " successfully added!");
        } else if (Cmember instanceof UniversityClub) {
            sportsClubsList.add(Cmember);
            System.out.println();
            System.out.println(Cmember.getName() + " successfully added!");
        } else {
            System.out.println("Full");
        }
        try {
            FileOutputStream fileOut = new FileOutputStream("Data.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(sportsClubsList);
            objectOut.close();
            fileOut.close();
            System.out.println(Cmember.getName() + " successfully added!");
            ReadClubMemberList();
        } catch (IOException i) {
            i.printStackTrace();
        }


    }

    //Method of deleting members from the array list
    @Override
    public void DeleteFootBallClub (String reg_id ) {
        ReadClubMemberList();
        FootBallClub deleteClub = null;
        for (FootBallClub Cmember : sportsClubsList) {
            if (Cmember.getRegistration_Number().equals(reg_id)) {
                deleteClub = Cmember;
            } else{
                System.out.println("Invalid Registration Number.");
            }
            if (deleteClub != null) {
                sportsClubsList.remove(deleteClub);
                try {
                    FileOutputStream fileOut = new FileOutputStream("Data.txt");
                    ObjectOutputStream out = new ObjectOutputStream(fileOut);
                    out.writeObject(sportsClubsList);
                    out.close();
                    fileOut.close();
                    System.out.println("Registration Number of the Club " + deleteClub.getRegistration_Number());
                    System.out.println("Name of the Deleted Club" + deleteClub.getName());
                    ReadClubMemberList();
                } catch (IOException i) {
                    i.printStackTrace();
                }
break;
            }
        }

    }

    //Sorting the array data under points and goals difference
    public int compare(FootBallClub A , FootBallClub B) {
        int x = sportsClubsList.size();
        FootBallClub footBallClub = null;
        for (int i = 0; i < x; i++) {

            for (int j = 1; j < (x - i); j++) {
                if ((sportsClubsList.get(j - 1)).getPoints() < ((sportsClubsList.get(j)).getPoints())) {
                    footBallClub = sportsClubsList.get(j - 1);
                    sportsClubsList.set(j - 1, sportsClubsList.get(j));
                    sportsClubsList.set(j, footBallClub);
                } else if (A.getPoints() == B.getPoints()){
                    int goalDif = A.getNum_of_Goals_Scored() - A.getNum_of_Goals_Received();
                    int goalDif1 = B.getNum_of_Goals_Scored() - B.getNum_of_Goals_Received();
                    if (goalDif > goalDif1)
                        return -1;
                    else if (goalDif < goalDif1)
                        return 1;
                    else return 0;
                }
            }


        }
        return x;
    }
//    public ObservableList<FootBallClub>getFootBallCLub(){
//        ReadClubMemberList();
//        Collections.sort(sportsClubsList,this::compare);
//        ObservableList<FootBallClub>footBallClubObservableList = FXCollections.observableArrayList();
//        for (FootBallClub fClub:sportsClubsList){
//            footBallClubObservableList.addAll(fClub);
//
//        }
//
//        return footBallClubObservableList;
//    }

//displaying premier league table in cli
    @Override
    public void DisplayPremierLeagueTable () {
        ReadClubMemberList();
        Collections.sort(sportsClubsList,this::compare);



        String Name = "Name of the Club";
        String Reg_id = "Registration Id";
        String Cap_Name = "Name of Captain";
        String Member_Count = "Member Count";
        String Num_of_Wins = "Wins";
        String Num_of_Defeats = "Defeats";
        String Num_of_Draws = "Draws";
        String Num_of_Matches = "Matches";
        String Goal_Soc = "Scored Goals";
        String Goal_received = "Received Goals";
        String Points = "Points";
        System.out.println("                                         ******************************Premier League Table******************************             ");
        System.out.println(" __________________________________________________________________________________________________________________________________________________________");
        System.out.printf(" |%-15s|%-15s|%-15s|%-15s|%-10s|%-10s|%-10s|%-10s|%-15s|%-15s|%-10s|\n", Name, Reg_id, Cap_Name, Member_Count, Num_of_Wins, Num_of_Defeats, Num_of_Draws, Num_of_Matches, Goal_Soc, Goal_received, Points);
        System.out.println(" __________________________________________________________________________________________________________________________________________________________");
        for (FootBallClub CMember : sportsClubsList) {
            System.out.printf(" |%-16s| %-14s| %-14s| %-14s| %-9s| %-10s| %-9s| %-9s| %-12s| %-13s |  %-10s|\n", CMember.getName(), CMember.getRegistration_Number(), CMember.getCaptain_Name(), CMember.getMember_Count(), CMember.getNum_of_Wins(), CMember.getNum_of_defeats(), CMember.getNum_of_draws(), CMember.getNum_of_Matches(), CMember.getNum_of_Goals_Scored(), CMember.getNum_of_Goals_Received(), CMember.getPoints());
            System.out.println(" __________________________________________________________________________________________________________________________________________________________");
        }

    }




//Showing searched team details
    @Override
    public FootBallClub TeamDetails(String reg_id){
        ReadClubMemberList();

        FootBallClub selectedClub = null;
        for (FootBallClub Cmember : sportsClubsList) {

            String RegID = Cmember.getRegistration_Number();
            if (RegID.equals(reg_id)) {

                selectedClub = Cmember;


            }}
        return selectedClub;
    }


//Adding played match details (updating)
    @Override
    public void PlayedMatchDetails () {
        ReadClubMemberList();
        Match newMatch = new Match();
        Date date;
        FootBallClub homeTeam = null;
        System.out.println("****************Played Match Details****************");
        System.out.println("Enter Match Date (format DD-MM-YYYY):");
        Scanner details = new Scanner(System.in);
        String  mDate = details.nextLine();
        try {
            date = new SimpleDateFormat("DD-MM-YYYY").parse(mDate);
        } catch (ParseException ex) {
            System.out.println("You have to enter date in format DD-MM-YYYY");
            return;
        }

        System.out.print("Enter  Registration Id of the Home team :");
        String reg_Number1 = details.next();
        for (FootBallClub footBallClub : sportsClubsList) {
            if (footBallClub.getRegistration_Number().equals(reg_Number1))
                homeTeam = footBallClub;
        }
        if(homeTeam == null){
            System.out.println("There is no club with Registration Number");
            return;
        }
        System.out.print("Enter Registration Id of the Away team :");
        String reg_Number2 = details.next();
        FootBallClub AwayTeam = null;
        for (FootBallClub footBallClub : sportsClubsList){
            if (footBallClub.getRegistration_Number().equals(reg_Number2))
                AwayTeam =footBallClub;
        }
        if (AwayTeam == null){
            System.out.println("There is no club with Registration Number");
            return;
        }
        int homeGoals = 0;
        homeGoals = validation.getIntegerInput("         Number of Goals Scored By Home Team :","         Number of Goals Scored Error Enter Again :" );


        int awayGoals = 0;
        awayGoals = validation.getIntegerInput("         Number of Goals Scored By Away Team :","         Number of Goals Scored Error Enter Again :" );



        newMatch.setHomeTeam(homeTeam);
        newMatch.setAwayTeam(AwayTeam);
        newMatch.setHomeTeamScore(homeGoals);
        newMatch.setAwayTeamScore(awayGoals);
        newMatch.setDate(date);
        matches.add(newMatch);
        homeTeam.setNum_of_Goals_Scored(homeTeam.getNum_of_Goals_Scored()+homeGoals);
        AwayTeam.setNum_of_Goals_Scored(AwayTeam.getNum_of_Goals_Scored()+awayGoals);
        homeTeam.setNum_of_Goals_Received(homeTeam.getNum_of_Goals_Received()+awayGoals);
        AwayTeam.setNum_of_Goals_Received(AwayTeam.getNum_of_Goals_Received()+homeGoals);
        homeTeam.setNum_of_Matches(homeTeam.getNum_of_Matches()+1);
        AwayTeam.setNum_of_Matches(AwayTeam.getNum_of_Matches()+1);

        if(homeGoals > awayGoals){
            homeTeam.setPoints(homeTeam.getPoints()+3);
            homeTeam.setNum_of_Wins(homeTeam.getNum_of_Wins()+1);
            AwayTeam.setNum_of_defeats(AwayTeam.getNum_of_defeats()+1);

        }else if(homeGoals < awayGoals){
            AwayTeam.setPoints(AwayTeam.getPoints()+3);
            AwayTeam.setNum_of_Wins(AwayTeam.getNum_of_Wins()+1);
            homeTeam.setNum_of_defeats(homeTeam.getNum_of_defeats()+1);
        }else {
            homeTeam.setPoints(homeTeam.getPoints()+1);
            AwayTeam.setPoints(AwayTeam.getPoints()+1);
            homeTeam.setNum_of_draws(homeTeam.getNum_of_draws()+1);
            AwayTeam.setNum_of_draws(AwayTeam.getNum_of_draws()+1);
        }
        try {
            FileOutputStream fileOut = new FileOutputStream("Data.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(sportsClubsList);
            objectOut.close();
            fileOut.close();
            System.out.println(homeTeam.getName() + " successfully added!");
            ReadClubMemberList();
        } catch (IOException i) {
            i.printStackTrace();
        }

    }
    public  ArrayList<FootBallClub> getClubs(){
        ReadClubMemberList();
        Collections.sort(sportsClubsList,this::compare);
        return sportsClubsList;
    }
    public ArrayList<Match> getMatches() {
        ReadClubMemberList();
        return matches;
    }




}
