package services;

import java.util.Scanner;

public class Validation {
    static Scanner V_Scanner = new Scanner(System.in);

    public static boolean Integer(String userInput){
        try{
            Integer num = Integer.parseInt(userInput);
            return true;
        } catch(Exception exception){
            return false;
        }
    }

    public Integer getIntegerInput(String InputMessage, String ErrorMassage){
        while (true){
            System.out.print(InputMessage);
            String userInput = V_Scanner.next();
            if (Integer(userInput)){
                return Integer.parseInt(userInput);
            }else {
                System.out.print(ErrorMassage);
            }
        }
    }


}
