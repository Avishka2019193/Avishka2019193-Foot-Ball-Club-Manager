import java.io.Serializable;
import java.util.Objects;

public  class FootBallClub extends SportsClub implements Serializable {
    //Initialize variables
    private int Num_of_Wins;
    private int Num_of_defeats;
    private int Num_of_draws;
    private String Season;
    private int Num_of_Matches;
    private int Num_of_Goals_Received;
    private int Num_of_Goals_Scored;
    private int Points;
    private String CoachName;
    private String Captain_Name;
    private int Member_Count;

    //Creating Default Constructor
    public FootBallClub() {}

    public FootBallClub(String name, String location, String name_Of_the_Manager, String registration_Number, int contact_Num, String email_of_the_Club, int num_of_Wins, int num_of_defeats, int num_of_draws, String season, int num_of_Matches, int num_of_Goals_Received, int num_of_Goals_Scored, int points, String coachName, String captain_Name, int member_Count) {
        super(name, location, name_Of_the_Manager, registration_Number, contact_Num, email_of_the_Club);
        this.Num_of_Wins = num_of_Wins;
        this.Num_of_defeats = num_of_defeats;
        this.Num_of_draws = num_of_draws;
        this. Season = season;
        this.Num_of_Matches = num_of_Matches;
        this.Num_of_Goals_Received = num_of_Goals_Received;
        this.Num_of_Goals_Scored = num_of_Goals_Scored;
        this. Points = points;
        this. CoachName = coachName;
        this.Captain_Name = captain_Name;
        this.Member_Count = member_Count;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FootBallClub)) return false;
        if (!super.equals(o)) return false;
        FootBallClub that = (FootBallClub) o;
        return getCoachName().equals(that.getCoachName()) &&
                getCaptain_Name().equals(that.getCaptain_Name());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getCoachName(), getCaptain_Name());
    }
    //Getters and setters
    public int getNum_of_Wins() {
        return Num_of_Wins;
    }

    public void setNum_of_Wins(int num_of_Wins) {
        this.Num_of_Wins = num_of_Wins;
    }

    public int getNum_of_defeats() {
        return Num_of_defeats;
    }

    public void setNum_of_defeats(int num_of_defeats) {
        this.Num_of_defeats = num_of_defeats;
    }

    public int getNum_of_draws() {
        return Num_of_draws;
    }

    public void setNum_of_draws(int num_of_draws) {
        this.Num_of_draws = num_of_draws;
    }

    public String getSeason() {
        return Season;
    }

    public void setSeason(String season) {
        this. Season = season;
    }

    public int getNum_of_Matches() {
        return Num_of_Matches;
    }

    public void setNum_of_Matches(int num_of_Matches) {
        this. Num_of_Matches = num_of_Matches;
    }

    public int getNum_of_Goals_Received() {
        return Num_of_Goals_Received;
    }

    public void setNum_of_Goals_Received(int num_of_Goals_Received) {
        this.Num_of_Goals_Received = num_of_Goals_Received;
    }

    public int getNum_of_Goals_Scored() {
        return Num_of_Goals_Scored;
    }

    public void setNum_of_Goals_Scored(int num_of_Goals_Scored) {
        this.Num_of_Goals_Scored = num_of_Goals_Scored;
    }

    public int getPoints() {
        return Points;
    }

    public void setPoints(int points) {
        this.Points = points;
    }

    public String getCoachName() {
        return CoachName;
    }

    public void setCoachName(String coachName) {
        this.CoachName = coachName;
    }

    public String getCaptain_Name() {
        return Captain_Name;
    }

    public void setCaptain_Name(String captain_Name) {
        this.Captain_Name = captain_Name;
    }

    public int getMember_Count() {
        return Member_Count;
    }

    public void setMember_Count(int member_Count) {
        this.Member_Count = member_Count;
    }

    @Override
    public String toString() {
        return "FootBallClub{" + super.toString()+
                "Num_of_Wins=" + Num_of_Wins +
                ", Num_of_defeats=" + Num_of_defeats +
                ", Num_of_draws=" + Num_of_draws +
                ", Season='" + Season + '\'' +
                ", Num_of_Matches=" + Num_of_Matches +
                ", Num_of_Goals_Received=" + Num_of_Goals_Received +
                ", Num_of_Goals_Scored=" + Num_of_Goals_Scored +
                ", Points=" + Points +
                ", CoachName='" + CoachName + '\'' +
                ", Captain_Name='" + Captain_Name + '\'' +
                ", Member_Count=" + Member_Count +
                '}';
    }
}
