
public interface LeagueManager {

    public void AddNewFootBallClub(FootBallClub Cmember);
    public void DeleteFootBallClub(String reg_id );
    public void DisplayPremierLeagueTable();
    public FootBallClub TeamDetails(String reg_id);
    public void PlayedMatchDetails();



}