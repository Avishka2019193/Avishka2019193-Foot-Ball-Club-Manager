
import java.awt.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;

public class MainCli {
    //Calling premierLeagueManager Class
    public PremierLeagueManager premierLeagueManager = new PremierLeagueManager();
    private static Validation validation = new Validation();

    //Console Menu
    public void displayMenu()  {

        System.out.println("\n**** Welcome to Premier League  Main Menu ****\n");
        System.out.println("         Option 1: Add a Member to the Sports Club");
        System.out.println("         Option 2: Delete a Member From the Sports Club");
        System.out.println("         Option 3: Display details of a club" );
        System.out.println("         Option 4: Premier League Table / GUI ");
        System.out.println("         Option 5: Played Match details");
        System.out.println("         Option 6: Quit Program");
        userInput();


    }

    //Menu method
    private  void userInput() {


        URL url = null;
        System.out.println();




        int userInput=0;
        userInput = validation.getIntegerInput("\nEnter an option: ","Invalid Input Type ... Please Enter option again:");

        if (userInput == 1 || userInput == 2 || userInput == 3 || userInput == 4|| userInput == 5|| userInput == 6) {
            if (userInput == 1) {
                AddNewFootballClub();
            } else if (userInput == 2) {
                DeleteFootBallClub();
            } else if (userInput == 3) {
                TeamDetails();
            } else if (userInput == 4) {
                premierLeagueManager.DisplayPremierLeagueTable();
                openGui();


            } else if (userInput == 5) {
                premierLeagueManager.PlayedMatchDetails();
            }else if(userInput==6){
                System.exit(200);
            }
        }else{
            System.out.println();
            System.out.println("Invalid option!!");


        }
        displayMenu();


    }
//    private void ShowGUI() {
//        GUI.launch();
//
//
//
//    }
    //Method for opening GUI
    private void openGui(){
        try {
            Desktop.getDesktop().browse(new URL("http://localhost:4000").toURI());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    //Method for team Details in CLI
    private void TeamDetails() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the club registration id :");
        String reg_id = input.next();
        FootBallClub selectedClub = premierLeagueManager.TeamDetails(reg_id);


        if(selectedClub==null) {
            System.out.println("Invalid Registration ID" );
        }
        else{
            System.out.println();
            System.out.println("***************************Club Details***************************");
            System.out.println();
            System.out.println("        Club Name :"+selectedClub.getName());
            System.out.println("        Club Registration Id :"+selectedClub.getRegistration_Number());
            System.out.println("        Club location :"+selectedClub.getLocation());
            System.out.println("        Manager Name :"+selectedClub.getName_Of_the_Manager());
            System.out.println("        Coach Name   :"+selectedClub.getCoachName());
            System.out.println("        Captain Name   :"+selectedClub.getCaptain_Name());
            System.out.println("        Email :"+selectedClub.getEmail_of_the_Club());
            System.out.println("        Contact Id :"+selectedClub.getContact_Num());
            System.out.println("        Matches :"+selectedClub.getNum_of_Matches());
            System.out.println("        Wins   : "+selectedClub.getNum_of_Wins());
            System.out.println("        Defeats :"+selectedClub.getNum_of_defeats());
            System.out.println("        Draws   :"+selectedClub.getNum_of_draws()  );
            System.out.println("        Scored Goals   :"+selectedClub.getNum_of_Goals_Scored()  );
            System.out.println("        Received Goals   :"+selectedClub.getNum_of_Goals_Scored());
            System.out.println("        MemberCount : "+selectedClub.getMember_Count());




        }

    }

    //Delete Method
    private  void DeleteFootBallClub() {

        Scanner input2 = new Scanner(System.in);
        System.out.println("*************Delete Member*************");
        System.out.print("      Enter the club registration id :");
        String reg_id = input2.next();
        premierLeagueManager.DeleteFootBallClub(reg_id);



    }
    //Method for Adding a new club
    private  void AddNewFootballClub() {
        Scanner input1 = new Scanner(System.in);
        System.out.println();

        System.out.println("***************************************************" );
        System.out.println("                Enter Club details                  ");
        System.out.println("***************************************************" );

        System.out.print("         Enter club Name :");
        String name = input1.next();
        while (!name.matches("[a-zA-Z]+")){
            System.out.println("      !!Invalid Input!!");
            System.out.print("         Enter club Name :");
            name = input1.next();

        }

        System.out.print("         Location of the Club :");
        String location =input1.next();
        while (!location.matches("[a-zA-Z]+")){
            System.out.println("      !!Invalid Input!!");
            System.out.print("         Location of the Club :");
            location = input1.next();

        }


        System.out.print("         Name of the Manager :");
        String N_Manager = input1.next();
        while (!N_Manager.matches("[a-zA-Z]+")){
            System.out.println("      !!Invalid Input!!");
            System.out.print("         Name of the Manager :");
            N_Manager = input1.next();

        }

        System.out.print("         Registration Number of the Club :");
        String reg_Number = input1.next();


        int Con_Number = 0;
        Con_Number = validation.getIntegerInput("         Contact Number :","         Contact Number wrong Enter Again :");


        System.out.print("         Email of the Club : ");
        String Email = input1.next();


        int match_count =0;
        match_count = validation.getIntegerInput("         Number of Matches :","         Match Count Error Enter Again :");



        int wins = 0;
        wins = validation.getIntegerInput("         Number of Wins :","         Win Count Error Enter Again :" );


        int defeats = 0;
        defeats = validation.getIntegerInput("         Number of defeats :","         Defeats Count Error Enter Again :" );


        int draws = 0;
        draws = validation.getIntegerInput("         Number of draws :","         Draws Count Error Enter Again :" );

        while(match_count!= wins+defeats+draws){
            System.out.println("!! Win , Defeats and Draws should be Equal to Number Of matches !! ");
            System.out.print("         Number of Matches :");
            match_count = input1.nextInt();
            System.out.print("         Number of Wins :");
            wins = input1.nextInt();
            System.out.print("         Number of Defeats :");
            defeats = input1.nextInt();
            System.out.print("         Number of Draws :");
            draws = input1.nextInt();
        }



        System.out.print("         Season (2021) :");
        String season = input1.next();


        int points = 0;
        points = wins*3+ draws*1;


        int g_scored = 0;
        g_scored = validation.getIntegerInput("         Number of Goals Scored :","         Number of Goals Scored Error Enter Again :" );

        int g_received = 0;
        g_received = validation.getIntegerInput("         Number of Goals Received  :","         Number of Goals Received  Error Enter Again :" );

        System.out.print("         Name of the Coach :");
        String Coach = input1.next();
        while (!Coach.matches("[a-zA-Z]+")){
            System.out.println("      !!Invalid Input!!");
            System.out.print("         Name of the Coach :");
            Coach = input1.next();

        }
        System.out.print("         Name of the Captain :");
        String Name_Cap = input1.next();
        while (!Name_Cap.matches("[a-zA-Z]+")){
            System.out.println("      !!Invalid Input!!");
            System.out.print("         Name of the Captain :");
            Name_Cap = input1.next();

        }
        int Member_Count = 0;
        Member_Count = validation.getIntegerInput("         Member Count of the Club :","Member Count of the Club Error Enter Again :" );


        FootBallClub Cmember = null;




        int ClubType= 0;
        ClubType = validation.getIntegerInput("          Enter the club type 1-FootballClub ,2-SchoolFootBallClub , 3-UniversityFootBallClub :","Club Type is Wrong Re Enter Again :");


        if(ClubType==1){

            Cmember = new FootBallClub(name, location, N_Manager, reg_Number, Con_Number, Email, wins, defeats, draws, season, match_count, g_received, g_scored, points, Coach, Name_Cap, Member_Count);

        }
        else if (ClubType==2){
            System.out.println("        School Name:");
            String Scl_name = input1.next();
            Cmember = new SclFootBallClub(name,location,N_Manager,reg_Number,Con_Number,Email,wins,defeats,draws,season,match_count,g_received,g_scored,points,Coach,Name_Cap,Member_Count,Scl_name);

        }else if (ClubType==3){
            System.out.print("          University Name :");
            String Uni_Name = input1.next();
            System.out.print("          Club Year :");
            String Club_Year = input1.next();
            Cmember= new UniversityClub(name,location,N_Manager,reg_Number,Con_Number,Email,wins,defeats,draws,season,match_count,g_received,g_scored,points,Coach,Name_Cap,Member_Count,Uni_Name,Club_Year);

        }else {


        }premierLeagueManager.AddNewFootBallClub(Cmember);

        displayMenu();








    }



}


