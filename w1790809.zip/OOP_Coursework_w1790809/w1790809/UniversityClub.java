
public class UniversityClub extends FootBallClub {
    //Initialize variables
    private String Name_Of_University;
    private  String Club_Year;

    //Creating Default Constructor
    public UniversityClub(){}

    //Creating  Constructor
    public UniversityClub(String name, String location, String name_Of_the_Manager, String registration_Number, int contact_Num, String email_of_the_Club, int num_of_Wins, int num_of_defeats, int num_of_draws, String season, int num_of_Matches, int num_of_Goals_Received, int num_of_Goals_Scored, int points, String coachName, String captain_Name, int member_Count, String name_Of_University, String club_Year) {
        super(name, location, name_Of_the_Manager, registration_Number, contact_Num, email_of_the_Club, num_of_Wins, num_of_defeats, num_of_draws, season, num_of_Matches, num_of_Goals_Received, num_of_Goals_Scored, points, coachName, captain_Name, member_Count);
        this.Name_Of_University = name_Of_University;
        this.Club_Year = club_Year;
    }

    //Getters and Setters
    public String getName_Of_University() {
        return Name_Of_University;
    }



    public void setName_Of_University(String name_Of_University) {
        this.Name_Of_University = name_Of_University;
    }

    public String getClub_Year() {
        return Club_Year;
    }

    public void setClub_Year(String club_Year) {
        this.Club_Year = club_Year;
    }

    @Override
    public String toString() {
        return "UniversityClub{" + super.toString()+
                "Name_Of_University='" + Name_Of_University + '\'' +
                ", Club_Year='" + Club_Year + '\'' +
                '}';
    }
}
